# Compact evaluation evidence — IGI LG836619414

16 untouched original 682 × 682 JPEGs, original retailer-hosted grading PDF, and provenance/checksum manifest. No resizing or recompression.

Read near-face-up frames in this order across the rotation loop boundary: 246, 248, 250, 252, 254, 255, 000, 002, 004, 006, 008, 010. Compare bright/dark role changes in the centre, nested steps and windmills on both sides of face-up. No calibrated angles are known.

Frames 032, 096, 128 and 192 supply broader oblique/profile context. They are not independent lighting conditions or a calibrated multi-axis test.

Identity chain: matched Loupe360 certificate LG836619414 → supplier PD-249203 viewer. Supplier createdDate: 13 September 2025; report: 21 September 2026. Cause of discrepancy unknown. Official IGI verification pending.

Viewer: https://vision.diajewel360.com/Vision360.html?d=PD-249203
Report: https://dnyvsyhu34v1w.cloudfront.net/pdf/LG836619414.pdf

These frames were visually inspected for selection and integrity checked. No cut verdict is implied. Grey/black ordinary imagery does not confirm leakage. ASET/Ideal-Scope missing. All 256 source frames were recovered, but only these 16 are included to meet the 1,000,000-byte budget. Raw JSON batches, duplicate photographs and contact sheets omitted. Original frame indices and byte checksums are retained.

Face-up reading order: 240, 244, 248, 250, 252, 254, 0, 2, 4, 8, 12, 16 (wraps through frame 255 to 0). Context: 32, 80, 128, 208.

12 frames span changing centre/step/corner appearances on both sides of face-up, including dark bands and asymmetric states; 4 frames add broader oblique and profile evidence. Selected for coverage, not a cut verdict. Each is an original JPEG. Metadata top_index 250 is not a calibrated angle; the most square-on interval is around 254/0.

Full 256-frame recovery verified; 16 selected frames archived here. Omitted intermediate frames and other lighting/viewing axes limit evaluation. Original report and supplier still remain in the Pass 1 ZIP at IGI-LG756580087-compact-evaluation-evidence.zip. Independent IGI verification remains deferred by user preference.

Viewer: https://vision.diajewel360.com/Vision360.html?d=VL-131355
Loupe: https://loupe360.com/diamond/LG756580087/video/500/500
ASET/Ideal-Scope not found in bounded exact-certificate searches. No unsolicited retailer contact.
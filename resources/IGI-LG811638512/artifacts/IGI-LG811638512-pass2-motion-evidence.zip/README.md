# IGI-LG811638512 motion evidence

12 nearby face-up originals and 3 oblique/profile originals, preserving indexed order and bytes. Read manifest for provenance. This selection samples motion and does not establish leakage or calibrated angles.

Original selected frames: [244, 246, 248, 250, 252, 254, 255, 0, 2, 4, 6, 8, 64, 128, 192, 208]
Face-up progression wraps 255 to 0; 64/128/192/208 provide context. No calibrated angles or original playback timing. SVGs are retailer diagrams, not a facet scan. Full source 256 frames, 758x598; only 16 published. Report is in the existing pass1 bundle.

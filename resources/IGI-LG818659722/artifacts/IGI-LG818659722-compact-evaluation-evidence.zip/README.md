# IGI-LG818659722 curated evidence

Original supplier JPEGs ; retailer-hosted IGI PDF saved alongside ZIP. Certificate association: exact Quality Diamonds listing and public Loupe360 record agree on certificate, grades, all dimensions and supplier PD-230293.

Reading order: 246, 248, 250, 252, 254, 255, 000, 002, 004, 006, 008, 010, 032, 064, 128, 192

This is 16 selected originals from 256 recovered frames, not a complete motion archive. Original timing/angles and lighting setup unknown. ASET not found in supplied evidence. Independent IGI verification deferred by user preference. See selected-frame manifest for hashes, source batches and inspection extent.
